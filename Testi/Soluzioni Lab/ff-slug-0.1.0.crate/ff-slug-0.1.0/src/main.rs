const SUBS_I: &str = "àáâäæãåāăąçćčđďèéêëēėęěğǵḧîïíīįìıİłḿñńǹňôöòóœøōõőṕŕřßśšşșťțûüùúūǘůűųẃẍÿýžźż";
const SUBS_O: &str = "aaaaaaaaaacccddeeeeeeeegghiiiiiiiilmnnnnoooooooooprrsssssttuuuuuuuuuwxyyzzz";

fn conv(c: char) -> char {
    match SUBS_I
        .chars()
        .position(|x| x == c.to_lowercase().into_iter().next().unwrap())
    {
        Some(i) => SUBS_O.as_bytes()[i] as char,
        None => c,
    }
}

fn slugify(s: &str) -> String {
    let mut slug = String::new();
    for c in s.chars() {
        for c in c.to_lowercase() {
            let c = match conv(c) {
                x @ 'a'..='z' | x @ '0'..='9' => x,
                _ => '-',
            };
            if c != '-' {
                slug.push(c);
            } else if !slug.ends_with('-') {
                slug.push('-');
            }
        }
    }
    if slug.ends_with('-') && slug.len() > 1 {
        slug.pop();
    }
    slug
}

fn main() {
    println!("{}", slugify(&("Hello World!".to_uppercase())));
}

#[cfg(test)]
mod tests {

    #[test]
    fn test_empty_string() {
        assert_eq!("", super::slugify(&""));
    }

    #[test]
    fn multiple_words() {
        assert_eq!("hello-world", super::slugify(&"Hello World"));
    }

    #[test]
    fn accents() {
        assert_eq!("e-uno-slug", super::slugify(&"E' uno slug!"));
    }

    #[test]
    fn multiple_dashes() {
        assert_eq!("hello-world", super::slugify(&"Hello  World!!"));
    }

    #[test]
    fn only_special_chars() {
        assert_eq!("-", super::slugify(&"!@#$%^&*()"));
    }
}
